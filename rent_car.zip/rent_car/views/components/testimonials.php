<!-- Testimonials / Happy Customers -->
<section class="site-section testimonial-wrap" id="testimonials-section">
  <div class="container">
    <div class="row mb-5">
      <div class="col-12 text-center">
        <h2 class="section-title mb-3">Happy Customers</h2>
      </div>
    </div>
  </div>
  <div class="slide-one-item home-slider owl-carousel">

    <div>
      <div class="testimonial">
        <blockquote class="mb-5">
          <p>&ldquo;It saves customers information, so you do not have to constantly go back and re-enter. I like how you can modify the days without changing the amount of days the client has actually been in the car.&rdquo;</p>
        </blockquote>
        <figure class="mb-4 d-flex align-items-center justify-content-center">
          <div><img src="assets/images/person_3.jpg" alt="Image" class="w-50 img-fluid mb-3"></div>
          <p>Khalid</p>
        </figure>
      </div>
    </div>
    
    <div>
      <div class="testimonial">
        <blockquote class="mb-5">
          <p>&ldquo;Using this program was like a dream that had come true especially for folks like me that travel often. With this you can do a one-stop shop for a rental vehicle and it's ready when you land.&rdquo;</p>
        </blockquote>
        <figure class="mb-4 d-flex align-items-center justify-content-center">
          <div><img src="assets/images/person_2.jpg" alt="Image" class="w-50 img-fluid mb-3"></div>
          <p>Hamid</p>
        </figure>
        
      </div>
    </div>

    <div>
      <div class="testimonial">
        <blockquote class="mb-5">
          <p>&ldquo;And being able to track the service needed on our vehicles as fantastic. The previous program we were using did not allow for this and it's nice to be reminded whenever Services needed.&rdquo;</p>
        </blockquote>
        <figure class="mb-4 d-flex align-items-center justify-content-center">
          <div><img src="assets/images/person_4.jpg" alt="Image" class="w-50 img-fluid mb-3"></div>
          <p>Shahid</p>
        </figure>
      </div>
    </div>

  </div>
</section>