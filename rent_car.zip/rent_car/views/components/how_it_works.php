<!-- How-It Works -->
<div class="py-5 bg-light site-section how-it-works" id="howitworks-section">
  <div class="container">
    <div class="row mb-5 justify-content-center">
      <div class="col-md-7 text-center">
        <h2 class="section-title mb-3">How It Works</h2>
      </div>
    </div>
    <div class="row">
      <!-- Find Car -->
      <div class="col-md-4 text-center">
        <div class="pr-5">
          <span class="custom-icon flaticon-house text-primary"></span>
          <h3 class="text-dark">Find Car</h3>
          <p>Find car you want to rent online from your home.</p>
        </div>
      </div>

      <!-- Pay Ammount -->
      <div class="col-md-4 text-center">
        <div class="pr-5">
          <span class="custom-icon flaticon-coin text-primary"></span>
          <h3 class="text-dark">Pay Ammount</h3>
          <p>Pay the rent of car Online.</p>
        </div>
      </div>

      <!-- Get Car -->
      <div class="col-md-4 text-center">
        <div class="pr-5">
          <span class="custom-icon flaticon-location text-primary"></span>
          <h3 class="text-dark">Get Car</h3>
          <p>Car will go to location on given time.</p>
        </div>
      </div>
    </div>
  </div>  
</div>