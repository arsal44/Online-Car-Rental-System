<!-- Services -->
<section class="site-section border-bottom bg-light" id="services-section">
  <div class="container">
    <div class="row mb-5">
      <div class="col-12 text-center">
        <h2 class="section-title mb-3">Our Services</h2>
      </div>
    </div>
    <div class="row align-items-stretch">
      <div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up">
        <div class="unit-4 d-flex">
          <div class="unit-4-icon mr-4"><span class="text-primary flaticon-house"></span></div>
          <div>
            <h3>Search Cars</h3>
            <p>We have got a large fleet of vehicles from all the popular automobile brands.</p>
            <p><a href="contact.php">Learn More</a></p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up" data-aos-delay="100">
        <div class="unit-4 d-flex">
          <div class="unit-4-icon mr-4"><span class="text-primary flaticon-coin"></span></div>
          <div>
            <h3>Pay Online</h3>
            <p>To get the most out of your holiday time in Pakistan, we will advise you to pre-book 24-hours in advance to get a punctual service.</p>
            <p><a href="contact.php">Learn More</a></p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up" data-aos-delay="200">
        <div class="unit-4 d-flex">
          <div class="unit-4-icon mr-4"><span class="text-primary flaticon-home"></span></div>
          <div>
            <h3>Refound Policy</h3>
            <p>We have a friendly refond policy, You can refond back your money if you want to cancel your order.</p>
            <p><a href="contact.php">Learn More</a></p>
          </div>
        </div>
      </div>

      <div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up" data-aos-delay="400">
        <div class="unit-4 d-flex">
          <div class="unit-4-icon mr-4"><span class="text-primary flaticon-location"></span></div>
          <div>
            <h3>Car on Location</h3>
            <p>Our customer service is professional and friendly at the same time to make renting a car an easy procedure at your end.</p>
            <p><a href="contact.php">Learn More</a></p>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up" data-aos-delay="500">
        <div class="unit-4 d-flex">
          <div class="unit-4-icon mr-4"><span class="text-primary flaticon-mobile-phone"></span></div>
          <div>
            <h3>Online in clicks</h3>
            <p>Just fill in the form online to get a quote of any vehicle for the required number of days.</p>
            <p><a href="contact.php">Learn More</a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>