<!-- Members -->
<section class="site-section border-bottom" id="agents-section">
  <div class="container">
    <div class="row mb-5">
      <div class="col-md-7 text-left">
        <h2 class="section-title mb-3">Members:</h2>
        <p class="lead">Following are our members who are struggling hard to make Car Rental System easy for you.</p>
      </div>
    </div>
    <div class="row">

      <div class="col-md-6 col-lg-4 mb-4">
        <div class="team-member">
          <figure>
            <ul class="social">
              <li><a href="#"><span class="icon-facebook"></span></a></li>
              <li><a href="#"><span class="icon-twitter"></span></a></li>
              <li><a href="#"><span class="icon-linkedin"></span></a></li>
              <li><a href="#"><span class="icon-instagram"></span></a></li>
            </ul>
            <img src="assets/images/image.jpg" alt="Image" class="img-fluid">
          </figure>
          <div class="p-3">
            <h3 class="mb-2">M Arslan</h3>
            <span class="position">Owner</span>
            <br>
            <br>
            <b>Phone Number</b> 0301-0000001
          </div>
        </div>
      </div>

      <div class="col-md-6 col-lg-4 mb-4">
        <div class="team-member">
          <figure>
            <ul class="social">
              <li><a href="#"><span class="icon-facebook"></span></a></li>
              <li><a href="#"><span class="icon-twitter"></span></a></li>
              <li><a href="#"><span class="icon-linkedin"></span></a></li>
              <li><a href="#"><span class="icon-instagram"></span></a></li>
            </ul>
            <img src="assets/images/person_6.jpg" alt="Image" class="img-fluid">
          </figure>
          <div class="p-3">
            <h3 class="mb-2">Saleem</h3>
            <span class="position">Manager</span>
            <br>
            <br>
            <b>Phone Number</b> 0301-0000001
          </div>
        </div>
      </div>

      <div class="col-md-6 col-lg-4 mb-4">
        <div class="team-member">
          <figure>
            <ul class="social">
              <li><a href="#"><span class="icon-facebook"></span></a></li>
              <li><a href="#"><span class="icon-twitter"></span></a></li>
              <li><a href="#"><span class="icon-linkedin"></span></a></li>
              <li><a href="#"><span class="icon-instagram"></span></a></li>
            </ul>
            <img src="assets/images/person_7.jpg" alt="Image" class="img-fluid">
          </figure>
          <div class="p-3">
            <h3 class="mb-2">Akbar</h3>
            <span class="position">Dealer</span>
            <br>
            <br>
            <b>Phone Number</b> 0301-0000001
          </div>
        </div>
      </div>

    </div>
  </div>
</section>