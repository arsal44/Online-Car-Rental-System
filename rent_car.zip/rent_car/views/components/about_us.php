<!-- About Us -->
<section class="site-section" id="about-section">
  <div class="container">
    <div class="row">

      <!-- Images -->
      <div class="col-lg-6">
        <div class="owl-carousel slide-one-item-alt">
          <img src="assets/images/property_1.jpg" alt="Image" class="img-fluid">
          <img src="assets/images/property_2.jpg" alt="Image" class="img-fluid">
          <img src="assets/images/property_3.jpg" alt="Image" class="img-fluid">
          <img src="assets/images/property_4.jpg" alt="Image" class="img-fluid">
        </div>
        <div class="custom-direction">
          <a href="#" class="custom-prev">Prev</a><a href="#" class="custom-next">Next</a>
        </div>
      </div>

      <!-- Text -->
      <div class="col-lg-5 ml-auto">
        <h2 class="section-title mb-3">About Us</h2>
        <p class="lead">We offer one of the most professional car rental services throughout Pakistan.</p>
        <p> Our services extend to all the major cities such as Islamabad, Lahore, Karachi, Faisalabad, Rawalpindi and Sialkot. You can use our cars to visit holiday destinations in addition to commuting from one place to another.</p>
        <ul class="list-unstyled ul-check success">
          <li>24/7 Services</li>
          <li>Online Booking</li>
          <li>Large Fleet of Vehicles</li>
          <li>Online Payment</li>
          <li>Friendly Service</li>
        </ul>
        <p><a href="cars.php" class="btn btn-primary mr-2 mb-2">Rent a Car</a></p>
      </div>
    </div>
  </div>
</section>