<?php
  // Default Overlay Data
  $OVERLAY_DATA = [
    "img" => "assets/images/cars/benz.jpg",
    "title" => "Rent Car Online",
    "para" => "Rent a Car is a car rentals agency with outlets in the different cities of Pakistan. We offer comfortable and reasonable car rental services.",
    "scroll_btn" => true,
  ];

  // Overlay Customization (If $overlay variable is set)
  if(isset($overlay))
    foreach($overlay as $prop => $value)
      if(array_key_exists($prop, $OVERLAY_DATA))
        $OVERLAY_DATA[$prop] = $value;
?>

<!-- Overlay -->
<div class="site-blocks-cover overlay" style="background-image: url('<?=$OVERLAY_DATA['img']?>');" data-aos="fade" id="home-section">
  <div class="container">
    <div class="row align-items-center justify-content-center">
      <div class="col-md-6 mt-lg-5 text-center">
        <h1><?=$OVERLAY_DATA['title']?></h1>
        <p class="mb-5"><?=$OVERLAY_DATA['para']?></p>
      </div>
    </div>
  </div>
  <?php
    // If scroll_btn is true
    if($OVERLAY_DATA['scroll_btn']){
      ?>
        <!-- Scroll-Button -->
        <a href="#howitworks-section" class="smoothscroll arrow-down"><span class="icon-arrow_downward"></span></a>
      <?php
    }
  ?>
</div>