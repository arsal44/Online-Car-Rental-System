<?php
  if(isset($_POST['contact'])){
    if(
      isset($_POST['type'])
      && isset($_POST['title']) && !empty($_POST['title'])
      && isset($_POST['message']) && !empty($_POST['message'])
    ){
      extract($_POST);
      if(mysqli_query($con, "INSERT INTO feedbacks(customer_id, title, feedback_type, message) VALUES ('".$user['id']."', '$title', '$type', '$message');"))
      $msg = [
        'type' => 'success',
        'msg' => 'Tnaks for your submission!'
      ];
      else $msg = [
        'type' => 'error',
        'msg' => 'Unable to Submit your Feedback' . mysqli_error($con)
      ];
    } else $msg = [
      'type' => 'error',
      'msg' => 'Invalid Data'
    ];
  }
?>

<?php
  if(isset($msg)){
    ?><script>toastr.<?=$msg['type']."(\"".$msg['msg']."\");"?></script><?php
  }
?>

<!-- Feedback -->
<section class="site-section bg-light bg-image" id="feedback-section">
  <div class="container">
    <div class="row mb-5">
      <div class="col-12 text-center">
        <h2 class="section-title mb-3">Feedback</h2>
      </div>
    </div>
    <div class="row">
      <div class="col-12 mb-5">
        <!-- Feedback Form -->
        <form action="feedback.php" method="POST" class="p-5 bg-white">
          <input type="hidden" name="contact" value="true">
          <h2 class="h4 text-black mb-5">Give us Feedback</h2> 

          <div class="row form-group">
            <div class="col-md-6">
              <label class="text-black" for="title">Title</label> 
              <input type="text" id="title" name="title" class="form-control">
            </div>
            <div class="col-md-6">
              <label class="text-black" for="type">Type</label> 
              <select name="type" id="type" class="form-control">
                <option value="0">Guest Feedback</option>
                <option value="1">Experience Feedback</option>
              </select>
            </div>
          </div>

          <div class="row form-group">
            <div class="col-md-12">
              <label class="text-black" for="message">Message</label> 
              <textarea name="message" id="message" cols="30" rows="7" class="form-control" placeholder="Write your notes or questions here..."></textarea>
            </div>
          </div>

          <div class="row form-group">
            <div class="col-md-12">
              <input type="submit" value="Send Message" class="btn btn-primary btn-md text-white">
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
</section>