<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>


<!-- Mobile Menu -->
<div class="site-mobile-menu site-navbar-target">
  <div class="site-mobile-menu-header">
    <div class="site-mobile-menu-close mt-3">
      <span class="icon-close2 js-menu-toggle"></span>
    </div>
  </div>
  <div class="site-mobile-menu-body"></div>
</div>

<!-- Header & Navigation -->
<header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
  <div class="container">
    <div class="row align-items-center">
      
      <!-- Logo -->
      <div class="col-6 col-xl-2">
        <h1 class="mb-0 site-logo m-0 p-0">
          <a href="index.php" class="mb-0 d-flex align-items-center">
            <img src="/rent_car/uploads/images/carlogo.jpg" alt="Rent Car Logo" style="height: 40px; margin-right: 10px;">
            <span>RideOnRent</span>
          </a>
        </h1>
      </div>

      <!-- Desktop Navigation -->
      <div class="col-12 col-md-10 d-none d-xl-block">
        <nav class="site-navigation position-relative text-right" role="navigation">
          <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">

          <li><a href="index.php" class="nav-link <?php if ($current_page == 'index.php') echo 'active'; ?>">Home</a></li>
<li><a href="cars.php" class="nav-link <?php if ($current_page == 'cars.php') echo 'active'; ?>">Cars</a></li>
<li><a href="members.php" class="nav-link <?php if ($current_page == 'members.php') echo 'active'; ?>">Members</a></li>
<li><a href="about.php" class="nav-link <?php if ($current_page == 'about.php') echo 'active'; ?>">About</a></li>
<li><a href="contact.php" class="nav-link <?php if ($current_page == 'contact.php') echo 'active'; ?>">Contact</a></li>



            <?php
              if ($user['role'] != 'g') {
                if ($user['role'] == 'c') {
                  echo '<li><a href="feedback.php" class="nav-link">Feedback</a></li>';
                }
                echo '<li><a href="dashboard" class="nav-link">Dashboard</a></li>';
              } else {
                echo '<li><a href="login.php" class="nav-link">Login</a></li>';
              }
            ?>

          </ul>
        </nav>
      </div>

      <!-- Mobile Menu Toggle -->
      <div class="col-6 d-inline-block d-xl-none ml-md-0 py-3">
        <a href="#" class="site-menu-toggle js-menu-toggle text-black float-right">
          <span class="icon-menu h3"></span>
        </a>
      </div>

    </div>
  </div>
</header>
