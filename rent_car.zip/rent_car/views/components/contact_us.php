<?php
  if(isset($_POST['contact'])){
    if(
      isset($_POST['fname']) && !empty($_POST['fname'])
      && isset($_POST['lname']) && !empty($_POST['lname'])
      && isset($_POST['email']) && !empty($_POST['email'])
      && isset($_POST['subject']) && !empty($_POST['subject'])
      && isset($_POST['message']) && !empty($_POST['message'])
    ){
      extract($_POST);
      if(mysqli_query($con, "INSERT INTO contact_messages(fname, lname, email, subject, message) VALUES ('$fname', '$lname', '$email', '$subject', \"$message\");"))
      $msg = [
        'type' => 'success',
        'msg' => 'Tnaks for your submission! We\'ll contact you soon.'
      ];
      else $msg = [
        'type' => 'error',
        'msg' => 'Unable to Submit your Message' . mysqli_error($con)
      ];
    } else $msg = [
      'type' => 'error',
      'msg' => 'Invalid Data'
    ];
  }
?>

<?php
  if(isset($msg)){
    ?><script>toastr.<?=$msg['type']."(\"".$msg['msg']."\");"?></script><?php
  }
?>

<!-- Contact Us -->
<section class="site-section bg-light bg-image" id="contact-section">
  <div class="container">
    <div class="row mb-5">
      <div class="col-12 text-center">
        <h2 class="section-title mb-3">Contct Us</h2>
      </div>
    </div>
    <div class="row">
      <div class="col-md-7 mb-5">
        <!-- Contact Form -->
        <form action="contact.php" method="POST" class="p-5 bg-white">
          <input type="hidden" name="contact" value="true">
          <h2 class="h4 text-black mb-5">Contact Form</h2> 

          <div class="row form-group">
            <div class="col-md-6 mb-3 mb-md-0">
              <label class="text-black" for="fname">First Name</label>
              <input type="text" id="fname" name="fname" class="form-control">
            </div>
            <div class="col-md-6">
              <label class="text-black" for="lname">Last Name</label>
              <input type="text" id="lname" name="lname" class="form-control">
            </div>
          </div>

          <div class="row form-group">
            <div class="col-md-12">
              <label class="text-black" for="email">Email</label> 
              <input type="email" id="email" name="email" class="form-control">
            </div>
          </div>
          
          <div class="row form-group">
            <div class="col-md-12">
              <label class="text-black" for="subject">Subject</label> 
              <input type="text" id="subject" name="subject" class="form-control">
            </div>
          </div>

          <div class="row form-group">
            <div class="col-md-12">
              <label class="text-black" for="message">Message</label> 
              <textarea name="message" id="message" cols="30" rows="7" class="form-control" placeholder="Write your notes or questions here..."></textarea>
            </div>
          </div>

          <div class="row form-group">
            <div class="col-md-12">
              <input type="submit" value="Send Message" class="btn btn-primary btn-md text-white">
            </div>
          </div>

        </form>
      </div>

      <!-- Contact Phones / Addresses -->
      <div class="col-md-5">
        <div class="p-4 mb-3 bg-white">
          <p class="mb-0 font-weight-bold">Address</p>
          <p class="mb-4">203 CBA, Q-Scheme, Yazman Road, Bahawalpur, Pakistan</p>

          <p class="mb-0 font-weight-bold">Phones</p>
          <p class="mb-0"><a href="#">+92 300 0000001</a> (General)</p>
          <p class="mb-0"><a href="#">+92 300 0000002</a> (Orders)</p>
          <p class="mb-0"><a href="#">+92 300 0000003</a> (Payments)</p>
          <p class="mb-4"><a href="#">+92 300 0000004</a> (Complains)</p>

          <p class="mb-0 font-weight-bold">Email Addresses</p>
          <p class="mb-0"><a title="click to send mail" href="mailto:info@example.com">info@example.com</a> (General)</p>
          <p class="mb-0"><a title="click to send mail" href="mailto:orders@example.com">orders@example.com</a> (Orders)</p>
          <p class="mb-0"><a title="click to send mail" href="mailto:payments@example.com">payments@example.com</a> (Payments)</p>
          <p class="mb-0"><a title="click to send mail" href="mailto:complains@example.com">complains@example.com</a> (Complains)</p>
        </div>
      </div>
    </div>
  </div>
</section>