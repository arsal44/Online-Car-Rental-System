<?php
  // Fetch Cars
  $cars = [];
  if($qry=mysqli_query($con, "SELECT *, (SELECT title FROM brands WHERE brands.id=cars.brand_id) as brand FROM cars WHERE cars.id NOT IN (SELECT car_id FROM car_reservation WHERE order_status IN (1, 3));"))
  while($car=mysqli_fetch_assoc($qry))
  $cars[]=$car;
  else die("Unable to fetch cars from database");
?>
<!-- Cars -->
<div class="site-section" id="cars-section">
  <div class="container">
    <div class="row mb-5 align-items-center">
      <!-- Text -->
      <div class="col-md-7 text-left">
        <h2 class="section-title mb-3">Cars</h2>
        <p class="lead">Browser Cars in following:</p>
      </div>
      <!-- Navigation Controls -->
      <div class="col-md-5 text-left text-md-right">
        <div class="custom-nav1">
          <a href="#" class="custom-prev1">Previous</a><span class="mx-3">/</span><a href="#" class="custom-next1">Next</a>
        </div>
      </div>
    </div>

    <!-- Cars -->
    <div class="owl-carousel nonloop-block-13 mb-5">
      <?php
        foreach($cars as $car){
          extract($car);
          ?>
            <div class="property">
              <a href="assets/property-single.html">
                <img src="uploads/<?=$img_src?>" alt="Image" class="img-fluid">
              </a>
              <div class="prop-details p-3">
                <div><strong class="price"><?=$brand . " " . $title?></strong></div>
                <div class="mb-2 d-flex justify-content-between">
                  <span class="w">Rs. <?=$daily_rate?> / Day</span>
                </div>
                <div><?=$description?></div>

                <!-- Rent Car Form -->
                <form action="dashboard/customer_orders.php#new_order" method='POST'>
                  <input type="hidden" name="car_id" value="<?=$id?>">
                  <input type="submit" value="Rent" class="btn btn-dark mt-3 text-white">
                </form>
              </div>
            </div>
          <?php
        }
      ?>
      <!-- <div class="property">
        <a href="assets/property-single.html">
          <img src="assets/images/property_1.jpg" alt="Image" class="img-fluid">
        </a>
        <div class="prop-details p-3">
          <div><strong class="price">Car Name</strong></div>
          <div class="mb-2 d-flex justify-content-between">
            <span class="w">Rs. 1500 / Day</span>
          </div>
          <div>Description Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, perspiciatis neque .</div>
        </div>
      </div> -->
    </div>
    <div class="row justify-content-center">
      <div class="col-md-4">
        <a href="cars.php" class="btn btn-primary btn-block">View All Cars</a>
      </div>
    </div>
  </div>
</div>