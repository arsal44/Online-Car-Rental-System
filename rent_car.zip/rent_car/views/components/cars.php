<?php
  // Fetch Cars
  $cars = [];
  if($qry=mysqli_query($con, "SELECT *, (SELECT title FROM brands WHERE brands.id=cars.brand_id) as brand FROM cars WHERE cars.id NOT IN (SELECT car_id FROM car_reservation WHERE order_status IN (1, 3));"))
  while($car=mysqli_fetch_assoc($qry))
  $cars[]=$car;
  else die("Unable to fetch cars from database");
?>

<!-- Cars -->
<section class="site-section border-bottom" id="cars-section">
  <div class="container">
    <div class="row mb-5">
      <div class="col-md-7 text-left">
        <h2 class="section-title mb-3">Cars:</h2>
        <p class="lead">Select Car in followings</p>
      </div>
    </div>
    <div class="row">

      <?php
        foreach($cars as $car){
          extract($car);
          ?>
            <div class="col-md-6 col-lg-4 mb-4">
              <div class="team-member">
                <a href="uploads/<?=$img_src?>" title="click to view">
                  <figure>
                    <img src="uploads/<?=$img_src?>" alt="Car" class="img-fluid">
                  </figure>
                </a>
                <div class="p-3">
                  <h3 class="mb-2"><?=$brand?> <?=$title?></h3>
                  <span class="position">Rs. <?=$daily_rate?> / Day</span>
                  <br>
                  <br>
                  <p class="lead">
                    <?=$description?>
                  </p>
                  <br>
                  <table class="table">
                    <tr>
                      <th>Color</th>
                      <td>
                        <div class="bordered rounded p-3" style="background: <?=$color?>;"></div>
                      </td>
                    </tr>
                    <tr>
                      <th>Brand</th>
                      <td><?=$brand?></td>
                    </tr>
                    <tr>
                      <th>Model</th>
                      <td><?=$model?></td>
                    </tr>
                    <tr>
                      <th>Daily Rate</th>
                      <td>Rs. <?=$daily_rate?></td>
                    </tr>
                  </table>
                  <br>
                  <!-- Rent Car Form -->
                  <form action="dashboard/customer_orders.php#new_order" method="POST">
                    <input type="hidden" name="car_id" value="<?=$id?>">
                    <input type="submit" value="Rent Car" class="btn btn-primary btn-md text-white">
                  </form>
                </div>
              </div>
            </div>
          <?php
        }
      ?>
      <!-- <div class="col-md-6 col-lg-4 mb-4">
        <div class="team-member">
          <figure>
            <img src="assets/images/property_2.jpg" alt="Image" class="img-fluid">
          </figure>
          <div class="p-3">
            <h3 class="mb-2">Car Name</h3>
            <span class="position">Rs. 1500 / Day</span>
            <br>
            <br>
            <p class="lead">
              Description Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto sequi labore ea dolorum aut non molestias consectetur praesentium.
            </p>
            <input type="submit" value="Rent Car" class="btn btn-primary btn-md text-white">
          </div>
        </div>
      </div> -->
    </div>
  </div>
</section>