<?php
  $user_arr = auth_arr();
  $prefix = "../views/layouts/dashboard/";
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <?php
      include "${prefix}metas_and_links.php";
    ?>
  </head>

  <body>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
      <?php
        include "${prefix}header.php";
        include "${prefix}sidebar.php";
      ?>
      <div class="page-wrapper">