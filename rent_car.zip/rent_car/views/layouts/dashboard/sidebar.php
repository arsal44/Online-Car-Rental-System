<aside class="left-sidebar" data-sidebarbg="skin6">
  <div class="scroll-sidebar">
    <nav class="sidebar-nav">
      <ul id="sidebarnav">
        <li>
          <div class="user-profile d-flex no-block dropdown m-t-20">
              <div class="user-pic"><img src="../assets/dashboard/assets/images/users/1.jpg" alt="users" class="rounded-circle" width="40" /></div>
              <div class="user-content hide-menu m-l-10">
                <a href="#" class="" id="Userdd" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <h5 class="m-b-0 user-name font-medium"><?=$user_arr['fname']?> <?=$user_arr['lname']?>
                    <i class="fa fa-angle-down"></i></h5>
                    <span class="op-5 user-email"><?=$user_arr['email']?></span>
                </a>
                  <div class="dropdown-menu dropdown-menu-end" aria-labelledby="Userdd">
                      <a class="dropdown-item" href="profile.php"><i
                              class="ti-user m-r-5 m-l-5"></i> My Profile</a>
                      <a class="dropdown-item" href="logout.php"><i
                              class="fa fa-power-off m-r-5 m-l-5"></i> Logout</a>
                  </div>
              </div>
          </div>
        </li>
        <?php
          include "${prefix}menu.php";
        ?>
      </ul>
    </nav>
  </div>
</aside>