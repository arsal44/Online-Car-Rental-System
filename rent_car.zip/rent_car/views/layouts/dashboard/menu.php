<li class="p-15 m-t-10"><a href="index.php"
  class="btn d-block w-100 create-btn text-white no-block d-flex align-items-center"><i
  class="mdi mdi-view-dashboard"></i> <span class="hide-menu m-l-5">Dashboard</span> </a>
</li>
<?php
  if($user['role']=='a'){
    ?>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="customers.php" aria-expanded="false"><i class="mdi mdi-account-card-details"></i><span
        class="hide-menu">Customers</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="cars.php" aria-expanded="false"><i
        class="mdi mdi-car"></i><span class="hide-menu">Cars</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="orders.php" aria-expanded="false"><i class="mdi mdi-package"></i><span
        class="hide-menu">Orders</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="transections.php" aria-expanded="false"><i class="mdi mdi-format-list-numbers"></i><span
        class="hide-menu">Transections</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="feedbacks.php" aria-expanded="false"><i class="mdi mdi-arrange-send-backward"></i><span
        class="hide-menu">Feedbacks</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="contact.php" aria-expanded="false"><i class="mdi mdi-comment-text"></i><span
        class="hide-menu">Contact Messages</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="../" aria-expanded="false"><i class="mdi mdi-keyboard-backspace"></i><span
        class="hide-menu">Site View</span></a></li>
    <?php
  }
  elseif($user['role']=='c'){
    ?>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="customer_orders.php" aria-expanded="false"><i class="mdi mdi-package-variant-closed"></i><span
        class="hide-menu">Order</span></a></li>
      <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
        href="customer_payments.php" aria-expanded="false"><i class="mdi mdi-format-float-center"></i><span
        class="hide-menu">Payments</span></a></li>
    <?php
  }
?>
<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
  href="profile.php" aria-expanded="false"><i class="mdi mdi-account"></i><span
  class="hide-menu">Profile</span></a></li>
<li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
  href="logout.php" aria-expanded="false"><i class="mdi mdi-logout"></i><span
  class="hide-menu">Logout</span></a></li>