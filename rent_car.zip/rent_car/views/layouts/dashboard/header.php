<header class="topbar" data-navbarbg="skin5">
    <nav class="navbar top-navbar navbar-expand-md navbar-dark">
        <div class="navbar-header" data-logobg="skin5">
            <a class="navbar-brand" href="../">
                <b class="logo-icon">
                    Rent a Car
                </b>
            </a>
        </div>
    </nav>
</header>