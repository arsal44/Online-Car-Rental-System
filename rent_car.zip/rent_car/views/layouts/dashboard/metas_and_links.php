<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?=isset($title)?$title:"Dashboard"?></title>
<link rel="canonical" href="https://www.wrappixel.com/templates/xtreme-admin-lite/" />
<link rel="icon" type="image/png" sizes="16x16" href="../assets/dashboard/assets/images/favicon.png">
<link href="../assets/dashboard/assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
<link href="../assets/dashboard/dist/css/style.min.css" rel="stylesheet">
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- Data Tables -->
<link rel="stylesheet" href="../assets/data_table/css/bootstrap.css">
<link rel="stylesheet" href="../assets/data_table/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="../assets/data_table/css/buttons.bootstrap4.min.css">

<!-- Toastr -->
<!-- <link rel="stylesheet" href="../assets/tassets/toastr.min.css">
<script src="../assets/tassets/toastr.min.js"></script> -->
