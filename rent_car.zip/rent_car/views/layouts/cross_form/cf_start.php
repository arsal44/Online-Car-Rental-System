<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet" href="assets/cross_form/style.css">
    <script src="assets/cross_form/prefixfree.min.js"></script>
  </head>

  <body>
    <div class="container" onclick="onclick">
      <div class="top"></div>
      <div class="bottom"></div>