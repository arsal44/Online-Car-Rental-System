<?php
  if (!isset($VIEW_BASE))
  $VIEW_BASE = "views";
?>

<!DOCTYPE html>

<html lang="en">
  <head>
    <!-- Metas -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>Rent Car Online</title>

    <!-- Fonts -->
    <link href="assets/https://fonts.googleapis.com/css?family=Roboto:300,400,900|Playfair+Display:400,700,900 " rel="stylesheet">
    <link rel="stylesheet" href="assets/fonts/icomoon/style.css">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="assets/fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="assets/css/aos.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Toastr -->
    <link rel="stylesheet" href="assets/tassets/toastr.min.css">
    <script src="assets/tassets/jquery-3.6.0.min.js"></script>
    <script src="assets/tassets/toastr.min.js"></script>

    <link rel="stylesheet" href="assets/css/custom.css">
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  <div class="site-wrap">
    <?php
      include "$VIEW_BASE/components/navigation.php";
    ?>
  </div>