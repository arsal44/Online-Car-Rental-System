<?php
  // Assets
  if(!isset($REGISTER_ASSETS))
  $REGISTER_ASSETS = 'assets/register_form';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Login V13</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/fonts/iconic/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/vendor/animate/animate.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/vendor/css-hamburgers/hamburgers.min.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/vendor/animsition/css/animsition.min.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/vendor/select2/select2.min.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/vendor/daterangepicker/daterangepicker.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/css/util.css">
    <link rel="stylesheet" type="text/css" href="<?=$REGISTER_ASSETS?>/css/main.css">
  </head>
  <body style="background-color: #999999;">