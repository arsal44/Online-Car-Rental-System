<?php
  function upload_file($file, $sub_dir="", $base_dir="uploads"){
    $client_filename = basename($file['name']);
    $client_filename_parts = explode(".", $client_filename);
    $client_extension = $client_filename_parts[count($client_filename_parts)-1];

    $random_name = "file_" . time() . rand(1000000000, 9999999999) . ".$client_extension";
    $target = $base_dir . "/" . (!empty($sub_dir)?"${sub_dir}/":"") . $random_name;
    return move_uploaded_file($file["tmp_name"], $target)?$target:false;
  }
?>