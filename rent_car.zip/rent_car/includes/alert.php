<?php
  if(isset($msg)){
    ?>
      <div class="alert alert-<?=$msg['type']?>" onclick="this.classList.add('d-none');" style="cursor: pointer;" role="alert">
        <?=$msg['msg']?>
      </div>
    <?php
  }
?>