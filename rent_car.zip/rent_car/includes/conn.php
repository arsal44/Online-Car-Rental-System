<?php
  // Use Default if DB Configuration not set
  if(!isset($db_conf)) $db_conf = [
    "database" => "car_rental",
    "host" => "127.0.0.1",
    "user" => "root",
    "password" => ""
  ];

  // Connect
  $con = mysqli_connect(
    $db_conf['host'],
    $db_conf['user'],
    $db_conf['password'],
    $db_conf['database']
  );

  // Die if unable to connect
  if(!$con) die("Unable to connect to database");
?>