<?php
  // Database Configurations
  $db_conf = [
    "database" => "car_rental",
    "host" => "127.0.0.1",
    "user" => "root",
    "password" => ""
  ];
?>