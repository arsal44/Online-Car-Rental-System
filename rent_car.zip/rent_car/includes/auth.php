<?php
  // Start Session
  session_start();

  // Initial Value of $user variable
  $user = [
    "id" => isset($_SESSION['id'])?$_SESSION['id']:0,
    "role" => isset($_SESSION['role'])?$_SESSION['role']:"g",
  ];

  // Function to login user in session
  function login($id, $role){
    if(!in_array($role, ["a", "c"]))
    return false;

    global $_SESSION;
    global $user;
    $_SESSION['id'] = $user['id'] = $id;
    $_SESSION['role'] = $user['role'] = $role;
    return true;
  }

  // Functoin to get User data from DB
  function auth_arr(){
    global $user;
    global $con;

    $auth_arr = [];
    if(
      ($qry=mysqli_query($con, "SELECT * FROM admins WHERE id='".$user['id']."';"))
      && mysqli_num_rows($qry) > 0  
    ){
      $auth_arr = mysqli_fetch_assoc($qry);
      $auth_arr['role'] = 'a';
    } elseif (
      ($qry=mysqli_query($con, "SELECT * FROM customers WHERE id='".$user['id']."';"))
      && mysqli_num_rows($qry) > 0  
    ){
      $auth_arr = mysqli_fetch_assoc($qry);
      $auth_arr['role'] = 'c';
    }

    return $auth_arr;
  }

  // Logout User from sessoin
  function logout(){
    global $_SESSION;
    unset($_SESSION['id']);
    unset($_SESSION['role']);

    $user['id'] = 0;
    $user['role'] = 'g';
    return true;
  }

  // Register a new Customer
  function register_customer($user_data_array){
    // Accessing Global Variables
    global $con;
    if(!$con) return [ // Error return if $con not exists
      'success' => false,
      'msg' => 'Server side problem!'
    ];

    // Return Variable
    $ret = [
      'success' => false,
      'msg' => 'Unable to register!'
    ];

    // Configure Required Fields
    $REQUIRED_FIELDS = [
      "fname",
      "lname",
      "email",
      "cnic",
      "phone",
      "address",
      "passcode",
    ];

    // Validate Data
    foreach($REQUIRED_FIELDS as $field)
    if(!array_key_exists($field, $user_data_array))
    return $ret = [
      'success' => false,
      'msg' => "$field is required"
    ];

    // Build Query
    $sql = "INSERT INTO customers(`" . implode('`, `', $REQUIRED_FIELDS) . "`) VALUES (";
    foreach($REQUIRED_FIELDS as $field)
    $sql .= "'".$user_data_array[$field]."', ";
    $sql = substr($sql, 0, strlen($sql)-2) . ");";

    // Run Query
    if(mysqli_query($con, $sql))
    return $ret = [ // Success Return
      'success' => true,
      'msg' => "Registered Successfully"
    ];
    return $ret = [ // Failure Return
      'success' => false,
      'msg' => "Unable to register in Database!"
    ];
  }
?>