/* - DATABASE - */
DROP DATABASE IF EXISTS rent_car;
CREATE DATABASE IF NOT EXISTS rent_car;
USE rent_car;

/* - Admins - */
CREATE TABLE IF NOT EXISTS admins(
  id INT PRIMARY KEY AUTO_INCREMENT,
  fname VARCHAR(50) NOT NULL,
  lname VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL,
  passcode VARCHAR(32) NOT NULL DEFAULT '12345678'
);
/* - Customers - */
CREATE TABLE IF NOT EXISTS customers(
  id INT PRIMARY KEY AUTO_INCREMENT,
  fname VARCHAR(50) NOT NULL,
  lname VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL,
  cnic VARCHAR(15) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  address VARCHAR(300) NOT NULL,
  passcode VARCHAR(32) NOT NULL DEFAULT '12345678'
);

/* - Brands - */
CREATE TABLE IF NOT EXISTS brands(
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(100) NOT NULL
);
/* - Cars - */
CREATE TABLE IF NOT EXISTS cars(
  id INT PRIMARY KEY AUTO_INCREMENT,
  img_src VARCHAR(100) NOT NULL,
  title VARCHAR(100) NOT NULL,
  model YEAR NOT NULL,
  color VARCHAR(20) NOT NULL,
  brand_id INT NOT NULL,
  daily_rate FLOAT NOT NULL DEFAULT 0.0,
  description TEXT NOT NULL,
  FOREIGN KEY (brand_id) REFERENCES brands(id)
);

/* - Car Reservation - */
CREATE TABLE IF NOT EXISTS car_reservation(
  id INT PRIMARY KEY AUTO_INCREMENT,
  car_id INT NOT NULL,
  customer_id INT NOT NULL,
  driver BOOLEAN NOT NULL DEFAULT false,
  daily_rate FLOAT NOT NULL, /* Required here because it may change in future */
  start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  no_of_days INT NOT NULL,
  port_time TIME NOT NULL,
  port_address TEXT NOT NULL,
  port_lat FLOAT NOT NULL,
  port_lng FLOAT NOT NULL,
  message TEXT NOT NULL DEFAULT '',
  order_status INT NOT NULL DEFAULT 0,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  time TIME NOT NULL DEFAULT CURRENT_TIME,
  FOREIGN KEY (car_id) REFERENCES cars(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);
/*
  Order Statuses:
    0 => Pending Payment
    1 => Payment Completed
    2 => Payment Failed
    3 => On Rent
    4 => Completed
    5 => Refounded back to User
    6 => Rejected
*/

/* - Transections - */
CREATE TABLE transections(
  id INT PRIMARY KEY AUTO_INCREMENT,
  customer_id INT NOT NULL,
  amount FLOAT NOT NULL DEFAULT 0.0,
  transection_id VARCHAR(200) NOT NULL,
  transection_plateform INT NOT NULL DEFAULT 0,
  account_title VARCHAR(200) NOT NULL,
  transection_type INT NOT NULL DEFAULT 0,
  transection_date DATE NOT NULL DEFAULT CURRENT_DATE,
  transection_time TIME NOT NULL DEFAULT CURRENT_TIME,
  status INT NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT "We'll confirm transection soon.",
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  time TIME NOT NULL DEFAULT CURRENT_TIME,
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);
/*
  Transection Plateforms:
    0 => Bank Transfer
    1 => JazzCash
    2 => EasyPaisa
    3 => Other

  Transection Types:
    0 => Incoming
    1 => Outgoing

  Status:
    0 => Pending
    1 => Confirmed
    2 => Failed
*/

/* - Feedbacks - */
CREATE TABLE feedbacks(
  id INT PRIMARY KEY AUTO_INCREMENT,
  customer_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  feedback_type INT NOT NULL DEFAULT 0,
  message TEXT NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  time TIME NOT NULL DEFAULT CURRENT_TIME,
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);
/*
  Feedback Type:
    0 => Guest Review
    1 => Customer Experience
*/

/* - Contact Messages - */
CREATE TABLE contact_messages(
  id INT PRIMARY KEY AUTO_INCREMENT,
  fname VARCHAR(200) NOT NULL,
  lname VARCHAR(200) NOT NULL,
  email VARCHAR(200) NOT NULL,
  subject VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  time TIME NOT NULL DEFAULT CURRENT_TIME
);

/* - Seeding Admin - */
INSERT INTO admins(fname, lname, email, passcode) VALUES ('Admin', 'Name', 'admin@example.com', 'admin');