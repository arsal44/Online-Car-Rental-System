<?php
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  $VIEW_BASE="views";

  if(!in_array($user['role'], ['a']))
  header('location: ../login.php');

  // Update Status
  if(isset($_POST['update_status']) && isset($_POST['order_id']) && !empty($_POST['order_id'])){
    if(isset($_POST['status'])){
      extract($_POST);
      if($qry=mysqli_query($con, "SELECT * FROM car_reservation WHERE id=$order_id;")){
        if(mysqli_num_rows($qry) == 1){
          if(mysqli_query($con, "UPDATE car_reservation SET order_status=$status WHERE id=$order_id;"))
          $msg = [
            "type" => "success",
            "msg" => "Order Updated Successfully!",
          ];
          else $msg = [
            "type" => "danger",
            "msg" => "Error while Updating Order!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Order Does not Exists!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Unable to Confirm Order!",
      ];
    } else $msg []= [
      'type' => 'danger',
      'msg' => 'Invalid Data!',
    ];
  }

  // Fetch Cars
  $cars = [];
  if($qry=mysqli_query($con, "SELECT *, (SELECT title FROM brands WHERE brands.id=cars.brand_id) AS brand FROM cars;"))
  while($car=mysqli_fetch_assoc($qry))
  $cars[]=$car;
  else die("Unable to fetch cars from database");

  // Fetch Orders
  $orders = [];
  if($qry=mysqli_query($con, "SELECT car_reservation.id, car_reservation.car_id, car_reservation.customer_id, car_reservation.driver, car_reservation.daily_rate, car_reservation.start_date, car_reservation.no_of_days, car_reservation.port_time, car_reservation.port_address, car_reservation.port_lat, car_reservation.port_lng, car_reservation.message, car_reservation.date, car_reservation.time, car_reservation.order_status, customers.fname, customers.lname, customers.email, customers.cnic, customers.phone, customers.address FROM car_reservation INNER JOIN customers ON customers.id=car_reservation.customer_id ORDER BY date DESC, time DESC;"))
  while($order=mysqli_fetch_assoc($qry))
  $orders[]=$order;
  else die("Unable to fetch orders from database");


  // Order Statuses (to be used in actions column)
  $order_statuses = [
    0 => [
      'color' => 'primary',
      'txt' => 'Pending Payment',
    ],
    1 => [
      'color' => 'success',
      'txt' => 'Payment Completed',
    ],
    2 => [
      'color' => 'danger',
      'txt' => 'Payment Failed',
    ],
    3 => [
      'color' => 'primary',
      'txt' => 'On Rent',
    ],
    4 => [
      'color' => 'success',
      'txt' => 'Completed',
    ],
    5 => [
      'color' => 'warning',
      'txt' => 'Refounded back to User',
    ],
    6 => [
      'color' => 'danger',
      'txt' => 'Rejected',
    ],
  ];

  include "../views/layouts/dashboard/dashboard_start.php";
?>
<div class="p-3">
  <?php
    include "../includes/alert.php";
  ?>
</div>

<!-- Required Assets -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key="></script>
<script src="../assets/map/location-picker.min.js"></script>
<style type="text/css">
  #map {
    width: 100%!important;
    height: 400px!important;
    transition: height .4s ease!important;
  }
  #map.sm {
    height: 200px!important;
  }
</style>

<!-- Orders -->
<div class="jumbotron">
  <h1 class="display-4">Orders</h1>
  <p class="lead">
    Manage your orders in followings:
  </p>
  <hr class="my-5">
  <div style="overflow-x: auto;">
    <table id="data_table" class="data_table table table-striped table-bordered" style="width:150%">
      <thead>
        <th>#</th>
        <th>Car</th>
        <th>Customer</th>
        <th>Driver</th>
        <th>Days</th>
        <th>Amount</th>
        <th>Address</th>
        <th>Message</th>
        <th>Date - Time</th>
        <th>Status</th>
        <th>Actions</th>
      </thead>
      <tbody>
        <?php
          $counter=0;
          foreach($orders as $order){
            extract($order);
            $counter++;
            ?>
              <tr>
                <td><?=$counter?></td>
                <td>
                  <span class="text-primary" style="cursor:pointer;" title="<?=$phone?> <?=$email?>"><?=$fname . " " . $lname?></span>
                </td>
                <td>
                  <?php
                    foreach($cars as $car)
                    if($car['id']==$car_id){
                      echo $car['brand'] . " " . $car['title'] . " " . $car['model']; //. " (Rs. " . $car['daily_rate'] . " /  Day)";
                      break;
                    }
                  ?>
                </td>
                <td><?=$driver?"Yes":"No"?></td>
                <td><?=$no_of_days?></td>
                <td>
                  <?="Rs. $daily_rate x $no_of_days<br>= Rs. " . ($daily_rate * $no_of_days)?>
                </td>
                <td>
                  <!-- Address Modal Trigger -->
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_addr_<?=$id?>" title="Read">
                    <i class="fa fa-eye"></i>
                  </button>
                  <!-- Address Modal -->
                  <div class="modal fade" id="read_addr_<?=$id?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Address</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <p class="lead">
                            <?=$port_address?>
                          </p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- Map Location Form -->
                  <form action="../map.php" method="GET" class="text-center d-inline-block">
                    <input type="hidden" name="lat" value="<?=$port_lat?>">
                    <input type="hidden" name="lng" value="<?=$port_lng?>">
                    <button type="submit" class="btn btn-default btn-success" title="Map Location">
                      <i class="mdi mdi-map-marker-radius"></i>
                    </button>
                  </form>
                </td>
                <td>
                  <!-- Message Modal Trigger -->
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_msg_<?=$id?>" title="Read">
                    <i class="fa fa-eye"></i>
                  </button>
                  <!-- Message Modal -->
                  <div class="modal fade" id="read_msg_<?=$id?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Message</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <p class="lead">
                            <?=$message?>
                          </p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
                <td><?="$date $time"?></td>
                <td>
                  <?php
                    switch($order_status){
                      case 0:
                        echo 'Pending Payment'; 
                        break;
                      case 1:
                        echo 'Payment Completed'; 
                        break;
                      case 2:
                        echo 'Payment Failed'; 
                        break;
                      case 3:
                        echo 'On Rent'; 
                        break;
                      case 4:
                        echo 'Completed'; 
                        break;
                      case 5:
                        echo 'Refounded'; 
                        break;
                      case 6:
                        echo 'Rejected'; 
                        break;
                      default:
                        echo 'Unknown'; 
                    }
                  ?>
                </td>
                <td>
                  <form action="" method="POST" id="status_view_frm_<?=$id?>" class="d-none text-right">
                    <input type="hidden" name="update_status" value="true">
                    <input type="hidden" name="order_id" value="<?=$id?>" required>
                    <select name="status" id="status" class="form-control" style="width: 200px;" required>
                      <option value="" class="d-none">Status</option>
                      <?php
                        foreach ($order_statuses as $k=>$os) {
                          ?>
                            <option value="<?=$k?>" class="text-<?=$os['color']?>"<?=$order_status==$k?" selected":""?>><?=$os['txt']?></option>
                          <?php
                        }
                      ?>
                    </select>
                    <br>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Set</button>
                  </form>
                  <div id="status_view_txt_<?=$id?>">
                    <div class="text-<?=$order_statuses[$order_status]['color']?>">
                      <?=$order_statuses[$order_status]['txt']?>
                    </div>
                    <button class="btn btn-primary" onclick="document.getElementById('status_view_txt_<?=$id?>').classList.add('d-none');document.getElementById('status_view_frm_<?=$id?>').classList.remove('d-none');"><i class="fa fa-edit"></i></button>
                  </div>
                </td>
              </tr>
            <?php
          }
        ?>
      </tbody>
      <tfoot>
        <th>#</th>
        <th>Customer</th>
        <th>Car</th>
        <th>Driver</th>
        <th>Days</th>
        <th>Amount</th>
        <th>Address</th>
        <th>Message</th>
        <th>Date - Time</th>
        <th>Status</th>
        <th>Actions</th>
      </tfoot>
    </table>
  </div>
</div>

<?php
  include "../views/layouts/dashboard/dashboard_end.php";
?>