<?php
  // Required Files
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  $VIEW_BASE="views"; // Conf Var

  // Redirect No-Login
  if(!in_array($user['role'], ['c', 'a']))
  header('location: ../login.php');
    
  // Layout Start
  include "../views/layouts/dashboard/dashboard_start.php";
?>
<div class="row p-4 px-5 bg-white">
  <h1 class="display-4">Rent a Car</h1>
  <p class="lead">
    Welcome. You can rent cars here. Rent a Car is a car rentals agency with outlets in the different cities of Pakistan. We offer comfortable and reasonable car rental services.
  </p>
  <hr class="my-5">
  <p class="lead">
    We rent cars online. You can select a car and order that car on your location any time. Booking and Payment can be done online. Feel free to contact us.
  </p>
</div>
<div class="row p-4 px-5 bg-light">
  <h1 class="display-4">About</h1>
  <p class="lead">
    We have got a large fleet of vehicles from all the popular automobile brands. Just fill in the form online to get a quote of any vehicle for the required number of days. Our customer service is professional and friendly at the same time to make renting a car an easy procedure at your end.
  </p>
</div>
<?php
  // Layout End
  include "../views/layouts/dashboard/dashboard_end.php";
?>