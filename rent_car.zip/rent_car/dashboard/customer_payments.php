<?php
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  $VIEW_BASE="views";

  if(!in_array($user['role'], ['c']))
  header('location: ../login.php');

  // Make Payment
  if(isset($_POST['new_payment'])){
    if( // Validate Data
      isset($_POST['transection_date']) && !empty($_POST['transection_date'])
      && isset($_POST['transection_time']) && !empty($_POST['transection_time'])
      && isset($_POST['amount']) && !empty($_POST['amount']) && ($_POST['amount'] > 0)
      && isset($_POST['transection_plateform'])
      && isset($_POST['account_title']) && !empty($_POST['account_title'])
      && isset($_POST['transection_id']) && !empty($_POST['transection_id'])
    ){
      extract($_POST);
      if(in_array($transection_plateform, [0, 1, 2, 3])){
        if(mysqli_query($con, "INSERT INTO transections(customer_id, amount, transection_id, transection_plateform, account_title, transection_type, transection_date, transection_time) VALUES ('".$user['id']."', '$amount', '$transection_id', '$transection_plateform', '$account_title', 0, '$transection_date', '$transection_time');"))
        $msg = [
          "type" => "success",
          "msg" => "Transection Added Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Adding Transection!" . mysqli_error($con),
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Invalid Plateform for Payment!",
      ];
    } else
    $msg = [
      "type" => "danger",
      "msg" => "Invalid Data to Make Payment!",
    ];
  }

  // Fetch Transections
  $transections = [];
  if($qry=mysqli_query($con, "SELECT * FROM transections WHERE customer_id='".$user['id']."' ORDER BY date DESC, time DESC;"))
  while($transection=mysqli_fetch_assoc($qry))
  $transections[]=$transection;
  else die("Unable to fetch payments from database");

  $transection_plateforms = [
    0 => 'Bank Transfer',
    1 => 'JazzCash',
    2 => 'EasyPaisa',
    3 => 'Other'
  ];
  $transection_statuses = [
    0 => [
      'color' => 'primary',
      'txt' => 'Pending',
    ],
    1 => [
      'color' => 'success',
      'txt' => 'Confirmed',
    ],
    2 => [
      'color' => 'danger',
      'txt' => 'Failed',
    ],
  ];

  include "../views/layouts/dashboard/dashboard_start.php";
?>
<div class="p-3">
  <?php
    include "../includes/alert.php";
  ?>
</div>

<!-- Orders -->
<div class="jumbotron">
  <h1 class="display-4">Transections</h1>
  <p class="lead">
    All of your transections are listed below:
  </p>
  <hr class="my-5">
  <div style="overflow-x: auto;">
    <table id="data_table" class="data_table table table-striped table-bordered" style="width:130%">
      <thead>
        <th>#</th>
        <th>Amount</th>
        <th>Plateform</th>
        <th>Account Title</th>
        <th>Transection ID</th>
        <th>Date-Time</th>
        <th>Added On</th>
        <th>Message</th>
        <th>Status</th>
      </thead>
      <tbody>
        <?php
          $counter=0;
          foreach($transections as $transection){
            extract($transection);
            $counter++;
            ?>
              <tr>
                <td><?=$counter?></td>
                <td><?=$amount?></td>
                <td><?=$transection_plateforms[$transection_plateform]?></td>
                <td><?=$account_title?></td>
                <td><?=$transection_id?></td>
                <td><?=$transection_date." ".$transection_time?></td>
                <td><?=$date." ".$time?></td>
                <td>
                  <!-- Message Modal Trigger -->
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_msg_<?=$id?>" title="Read">
                    <i class="fa fa-eye"></i>
                  </button>
                  <!-- Message Modal -->
                  <div class="modal fade" id="read_msg_<?=$id?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Message</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <p class="lead">
                            <?=$note?>
                          </p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
                <td><span class="text-<?=$transection_statuses[$status]['color']?>"><?=$transection_statuses[$status]['txt']?></span></td>
              </tr>
            <?php
          }
        ?>
      </tbody>
      <tfoot>
        <th>#</th>
        <th>Amount</th>
        <th>Plateform</th>
        <th>Account Title</th>
        <th>Transection ID</th>
        <th>Date-Time</th>
        <th>Added On</th>
        <th>Message</th>
        <th>Status</th>
      </tfoot>
    </table>
  </div>
</div>

<!-- Place Order Form -->
<div class="jumbotron" id="new_payment">
  <h1 class="display-4">Make new Payment</h1>
  <p class="lead">
    Make your payment as follow
  </p>
  <hr>
  <form action="customer_payments.php" method="POST">
    <input type="hidden" name="new_payment" value="true">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="transection_date">Date</label>
          <input type="date" class="form-control" name="transection_date" id="transection_date" required>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="transection_time">Time</label>
          <input type="time" class="form-control" name="transection_time" id="transection_time" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="amount">Amount</label>
          <input type="number" step="0.01" class="form-control" name="amount" id="amount" placeholder="Amount" required <?=(isset($_POST['amount']) && is_numeric($_POST['amount']))?(" value='".$_POST['amount']."'"):""?>>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="transection_plateform">Plateform</label>
          <select name="transection_plateform" id="transection_plateform" class="form-control" required>
            <option value="" class="d-none" selected>Select One</option>
            <option value="0">Bank Transfer</option>
            <option value="1">JazzCash</option>
            <option value="2">EasyPaisa</option>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="account_title">Account Title</label>
          <input type="text" class="form-control" name="account_title" id="account_title" placeholder="Account Title" required>
        </div>
      </div>
      <div class="col-12">
        <div class="form-group">
          <label for="transection_id">Transection ID</label>
          <input type="text" class="form-control" name="transection_id" id="transection_id" placeholder="Enter Transection ID" required>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="mdi mdi-format-float-center"></i>
      Submit Payment Details
    </button>
    <button type="reset" class="btn btn-secondary">Reset</button>
  </form>
</div>

<?php
  include "../views/layouts/dashboard/dashboard_end.php";
?>