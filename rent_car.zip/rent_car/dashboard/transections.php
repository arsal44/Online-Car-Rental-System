<?php
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  $VIEW_BASE="views";

  if(!in_array($user['role'], ['a']))
  header('location: ../login.php');

  // Make Payment
  if(isset($_POST['new_payment'])){
    if( // Validate Data
      isset($_POST['transection_date']) && !empty($_POST['transection_date'])
      && isset($_POST['transection_time']) && !empty($_POST['transection_time'])
      && isset($_POST['amount']) && !empty($_POST['amount']) && ($_POST['amount'] > 0)
      && isset($_POST['transection_plateform'])
      && isset($_POST['transection_type'])
      && isset($_POST['customer_id'])
      && isset($_POST['account_title']) && !empty($_POST['account_title'])
      && isset($_POST['transection_id']) && !empty($_POST['transection_id'])
    ){
      extract($_POST);
      if(in_array($transection_plateform, [0, 1, 2, 3])){
        if(mysqli_query($con, "INSERT INTO transections(customer_id, amount, transection_id, transection_plateform, account_title, transection_type, transection_date, transection_time) VALUES ('$customer_id', '$amount', '$transection_id', '$transection_plateform', '$account_title', '$transection_type', '$transection_date', '$transection_time');"))
        $msg = [
          "type" => "success",
          "msg" => "Transection Added Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Adding Transection!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Invalid Plateform for Payment!",
      ];
    } else
    $msg = [
      "type" => "danger",
      "msg" => "Invalid Data to Make Payment!",
    ];
  }

  // Delete Transection
  if(isset($_POST['delete_transection_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM transections WHERE id=$delete_transection_id AND customer_id='".$user['id']."';")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM transections WHERE id=$delete_transection_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Transection Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting Transection!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Transection Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Transection!",
    ];
  }

  // Edit Note
  if(isset($_POST['edit_note']) && isset($_POST['transection_id']) && !empty($_POST['transection_id'])){
    if(isset($_POST['note'])){
      extract($_POST);
      if($qry=mysqli_query($con, "SELECT * FROM transections WHERE id=$transection_id;")){
        if(mysqli_num_rows($qry) == 1){
          if(mysqli_query($con, "UPDATE transections SET note=\"$note\" WHERE id=$transection_id;"))
          $msg = [
            "type" => "success",
            "msg" => "Transection Note Updated Successfully!",
          ];
          else $msg = [
            "type" => "danger",
            "msg" => "Error while Updating Transection Note!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Transection Does not Exists!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Unable to Confirm Transection!",
      ];
    } else $msg []= [
      'type' => 'danger',
      'msg' => 'Invalid Data!',
    ];
  }

  // Update Status
  if(isset($_POST['update_status']) && isset($_POST['transection_id']) && !empty($_POST['transection_id'])){
    if(isset($_POST['status'])){
      extract($_POST);
      if($qry=mysqli_query($con, "SELECT * FROM transections WHERE id=$transection_id;")){
        if(mysqli_num_rows($qry) == 1){
          if(mysqli_query($con, "UPDATE transections SET status=$status WHERE id=$transection_id;"))
          $msg = [
            "type" => "success",
            "msg" => "Transection Status Updated Successfully!",
          ];
          else $msg = [
            "type" => "danger",
            "msg" => "Error while Updating Transection Status!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Transection Does not Exists!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Unable to Confirm Transection!",
      ];
    } else $msg []= [
      'type' => 'danger',
      'msg' => 'Invalid Data!',
    ];
  }

  // Fetch Transections
  $transections = [];
  if($qry=mysqli_query($con, "SELECT transections.id, transections.customer_id, transections.amount, transections.transection_id, transections.transection_plateform, transections.account_title, transections.transection_type, transections.transection_date, transections.transection_time, transections.status, transections.note, transections.date, transections.time, customers.fname, customers.lname, customers.email, customers.cnic, customers.phone, customers.address FROM transections INNER JOIN customers ON customers.id=transections.customer_id ORDER BY date DESC, time DESC;"))
  while($transection=mysqli_fetch_assoc($qry))
  $transections[]=$transection;
  else die("Unable to fetch transections from database");

  // Fetch Customers
  $customers = [];
  if($qry=mysqli_query($con, "SELECT * FROM customers;"))
  while($customer=mysqli_fetch_assoc($qry))
  $customers[]=$customer;
  else die("Unable to fetch customers from database");

  $transection_plateforms = [
    0 => 'Bank Transfer',
    1 => 'JazzCash',
    2 => 'EasyPaisa',
    3 => 'Other'
  ];
  $transection_statuses = [
    0 => [
      'color' => 'primary',
      'txt' => 'Pending',
    ],
    1 => [
      'color' => 'success',
      'txt' => 'Confirmed',
    ],
    2 => [
      'color' => 'danger',
      'txt' => 'Failed',
    ],
  ];

  include "../views/layouts/dashboard/dashboard_start.php";
?>
<div class="p-3">
  <?php
    include "../includes/alert.php";
  ?>
</div>

<!-- Orders -->
<div class="jumbotron">
  <h1 class="display-4">Transections</h1>
  <p class="lead">
    All of your transections are listed below:
  </p>
  <hr class="my-5">
  <div style="overflow-x: auto;">
    <table id="data_table" class="data_table table table-striped table-bordered" style="width:160%">
      <thead>
        <th>#</th>
        <th>Customer</th>
        <th>Amount</th>
        <th>Type</th>
        <th>Plateform</th>
        <th>Account Title</th>
        <th>Transection ID</th>
        <th>Date-Time</th>
        <th>Added On</th>
        <th>Message</th>
        <th>Status</th>
        <th>Actions</th>
      </thead>
      <tbody>
        <?php
          $counter=0;
          foreach($transections as $transection){
            extract($transection);
            $counter++;
            ?>
              <tr>
                <td><?=$counter?></td>
                <td>
                  <span class="text-primary" style="cursor:pointer;" title="<?=$phone?> <?=$email?>"><?=$fname . " " . $lname?></span>
                </td>
                <td><?=$amount?></td>
                <td><?=$transection_type==0?"From Customer":"To Customer"?></td>
                <td><?=$transection_plateforms[$transection_plateform]?></td>
                <td><?=$account_title?></td>
                <td><?=$transection_id?></td>
                <td><?=$transection_date." ".$transection_time?></td>
                <td><?=$date." ".$time?></td>
                <td>
                  <!-- Message Modal Trigger -->
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_msg_<?=$id?>" title="Read">
                    <i class="fa fa-eye"></i>
                  </button>
                  <!-- Message Modal -->
                  <div class="modal fade" id="read_msg_<?=$id?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Message</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <p class="lead">
                            <?=$note?>
                          </p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Edit Message Modal Trigger -->
                  <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_msg_<?=$id?>" title="Edit">
                    <i class="fa fa-edit"></i>
                  </button>
                  <!-- Edit Message Modal -->
                  <div class="modal fade" id="edit_msg_<?=$id?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                      <form class="modal-content" action="" method="POST">
                        <input type="hidden" name="edit_note" value="true">
                        <input type="hidden" name="transection_id" value="<?=$id?>">
                        <div class="modal-header">
                          <h5 class="modal-title">Edit Message</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <p class="lead">
                            <textarea name="note" id="note" class="form-control" rows="4" placeholder="note" required><?=$note?></textarea>
                          </p>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-success">Save</button>
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </td>
                <td>
                  <form action="" method="POST" id="status_view_frm_<?=$id?>" class="d-none text-right">
                    <input type="hidden" name="update_status" value="true">
                    <input type="hidden" name="transection_id" value="<?=$id?>" required>
                    <select name="status" id="status" class="form-control" style="width: 200px;" required>
                      <option value="" class="d-none">Status</option>
                      <?php
                        foreach ($transection_statuses as $k=>$os) {
                          ?>
                            <option value="<?=$k?>" class="text-<?=$os['color']?>"<?=$status==$k?" selected":""?>><?=$os['txt']?></option>
                          <?php
                        }
                      ?>
                    </select>
                    <br>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Set</button>
                  </form>
                  <div id="status_view_txt_<?=$id?>">
                    <div class="text-<?=$transection_statuses[$status]['color']?>">
                      <?=$transection_statuses[$status]['txt']?>
                    </div>
                    <button class="btn btn-primary" onclick="document.getElementById('status_view_txt_<?=$id?>').classList.add('d-none');document.getElementById('status_view_frm_<?=$id?>').classList.remove('d-none');"><i class="fa fa-edit"></i></button>
                  </div>
                </td>
                <td>
                  <form action="" method="post" class="d-inline-block">
                    <input type="hidden" name="delete_transection_id" value="<?=$id?>">
                    <button type="submit" class="btn btn-danger">
                      <i class="fa fa-trash"></i>
                    </button>
                  </form>
                </td>
              </tr>
            <?php
          }
        ?>
      </tbody>
      <tfoot>
        <th>#</th>
        <th>Customer</th>
        <th>Amount</th>
        <th>Type</th>
        <th>Plateform</th>
        <th>Account Title</th>
        <th>Transection ID</th>
        <th>Date-Time</th>
        <th>Added On</th>
        <th>Message</th>
        <th>Status</th>
        <th>Actions</th>
      </tfoot>
    </table>
  </div>
</div>

<!-- Place Order Form -->
<div class="jumbotron" id="new_payment">
  <h1 class="display-4">Make new Payment</h1>
  <p class="lead">
    Make your payment as follow
  </p>
  <hr>
  <form action="transections.php" method="POST">
    <input type="hidden" name="new_payment" value="true">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="transection_date">Date</label>
          <input type="date" class="form-control" name="transection_date" id="transection_date" required>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="transection_time">Time</label>
          <input type="time" class="form-control" name="transection_time" id="transection_time" required>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="amount">Amount</label>
          <input type="number" step="0.01" class="form-control" name="amount" id="amount" placeholder="Amount" required <?=(isset($_POST['amount']) && is_numeric($_POST['amount']))?(" value='".$_POST['amount']."'"):""?>>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="transection_type">Type</label>
          <select name="transection_type" id="transection_type" class="form-control" required>
            <option value="0" selected>From Customer</option>
            <option value="1">To Customer</option>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="transection_plateform">Plateform</label>
          <select name="transection_plateform" id="transection_plateform" class="form-control" required>
            <option value="" class="d-none" selected>Select One</option>
            <option value="0">Bank Transfer</option>
            <option value="1">JazzCash</option>
            <option value="2">EasyPaisa</option>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="account_title">Account Title</label>
          <input type="text" class="form-control" name="account_title" id="account_title" placeholder="Account Title" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="transection_id">Transection ID</label>
          <input type="text" class="form-control" name="transection_id" id="transection_id" placeholder="Enter Transection ID" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="customer_id">Customer</label>
          <select name="customer_id" id="customer_id" class="form-control" required>
            <option value="" selected class="d-none">Select Customer</option>
            <?php
              foreach($customers as $customer){
                extract($customer);
                ?>
                  <option value="<?=$id?>"><?="$fname $lname ($phone)"?></option>
                <?php
              }
            ?>
          </select>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="mdi mdi-format-float-center"></i>
      Submit Payment Details
    </button>
    <button type="reset" class="btn btn-secondary">Reset</button>
  </form>
</div>

<?php
  include "../views/layouts/dashboard/dashboard_end.php";
?>