<?php
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  require "../includes/upload.php";
  $VIEW_BASE="views";

  if(!in_array($user['role'], ['a']))
  header('location: ../login.php');
  

  // Add Brand
  if(isset($_POST['add_brand'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM brands WHERE title = '$brand';")){
      if(mysqli_num_rows($qry) == 0){
        if(mysqli_query($con, "INSERT INTO brands(title) VALUES ('$brand');"))
        $msg = [
          "type" => "success",
          "msg" => "Brand Inserted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Inserting brand!",
        ];
      } else {
        $msg = [
          "type" => "danger",
          "msg" => "Brand Already Added!",
        ];
      }
    }
  }
  // Add Car
  if(isset($_POST['add_car'])){
    if( // Validate Data
      isset($_FILES['img_src'])
      && isset($_POST['title']) && !empty($_POST['title'])
      && isset($_POST['model']) && !empty($_POST['model'])
      && isset($_POST['color']) && !empty($_POST['color'])
      && isset($_POST['brand_id']) && !empty($_POST['brand_id'])
      && isset($_POST['daily_rate']) && !empty($_POST['daily_rate'])
      && isset($_POST['description']) && !empty($_POST['description'])
    ){ // Upload image
      if($upload_src=upload_file($_FILES['img_src'], "images", '../uploads')){
        extract($_POST);
        // Inset Data
        if(mysqli_query($con, "INSERT INTO cars(img_src, title, model, color, brand_id, daily_rate, description) VALUES ('$upload_src', '$title', '$model', '$color', '$brand_id', '$daily_rate', '$description');"))
          $msg = [
            "type" => "success",
            "msg" => "Car Inserted Successfully!",
          ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Inserting car!"
          . mysqli_error($con)
        ];
      }
    } else 
    $msg = [
      "type" => "danger",
      "msg" => "Invalid Data to add Car!",
    ];
  }

  // Update Brand
  if(isset($_POST['update_brand_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM brands WHERE id=$update_brand_id;")){
      if(mysqli_num_rows($qry) == 1){
        if($qry=mysqli_query($con, "SELECT * FROM brands WHERE title='$brand' AND id!=$update_brand_id;")){
          if(mysqli_num_rows($qry) == 0){
            if(mysqli_query($con, "UPDATE brands SET title='$brand' WHERE id=$update_brand_id;"))
            $msg = [
              "type" => "success",
              "msg" => "Brand Updated Successfully!",
            ];
            else $msg = [
              "type" => "danger",
              "msg" => "Error while Updating brand!",
            ];
          } else $msg = [
            "type" => "danger",
            "msg" => "Brand Name Already Exists!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Unable to Confirm Brand Name!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Brand Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Brand!",
    ];
  }
  // Update Car
  if(isset($_POST['update_car_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM cars WHERE id=$update_car_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "UPDATE cars SET title='$title', model='$model', color='$color', brand_id='$brand_id', daily_rate='$daily_rate', description='$description' WHERE id=$update_car_id;")){
          if(isset($_FILES['img_src'])){
            if($upload_src=upload_file($_FILES['img_src'], "images", '../uploads')){
              if(mysqli_query($con, "UPDATE cars SET img_src='$upload_src' WHERE id=$update_car_id;")){
                $msg = [
                  "type" => "success",
                  "msg" => "Car Updated Successfully!",
                ];
              }
            } $msg = [
              "type" => "warning",
              "msg" => "Car Saved but Image is not uploaded!",
            ];
          } $msg = [
            "type" => "success",
            "msg" => "Car Updated Successfully!",
          ];
        }
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Updating car!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Car Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Car!",
    ];
  }

  // Delete Brand
  if(isset($_POST['delete_brand_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM brands WHERE id=$delete_brand_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM brands WHERE Id=$delete_brand_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Brand Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting brand!" . (mysqli_errno($con)==1451?" Car(s) Exist with this brand! Delete them first.":""),
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Brand Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Brand!",
    ];
  }

  // Delete Car
  if(isset($_POST['delete_car_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM cars WHERE id=$delete_car_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM cars WHERE id=$delete_car_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Car Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting car!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Car Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Car!",
    ];
  }


  // Fetch Brands
  $brands = [];
  if($qry=mysqli_query($con, "SELECT * FROM brands;"))
  while($brand=mysqli_fetch_assoc($qry))
  $brands[]=$brand;
  else die("Unable to fetch brands from database");
  // Fetch Cars
  $cars = [];
  if($qry=mysqli_query($con, "SELECT * FROM cars;"))
  while($car=mysqli_fetch_assoc($qry))
  $cars[]=$car;
  else die("Unable to fetch cars from database");

  include "../views/layouts/dashboard/dashboard_start.php";
?>
<div class="p-3">
  <?php
    include "../includes/alert.php";
  ?>
</div>
<div class="jumbotron">
  <h1 class="display-4">Cars</h1>
  <p class="lead">
    Manage your cars in followings:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>Image</th>
      <th>Title</th>
      <th>Model</th>
      <th>Color</th>
      <th>Brand</th>
      <th title="Daily">Rate</th>
      <th>Description</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($cars as $car){
          extract($car);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td>
                <a href="<?=$img_src?>">
                  <img src="<?=$img_src?>" alt="Car Image" class="img rounded bordered" style="width: 150px; height: auto;">
                </a>
              </td>
              <td><?=$title?></td>
              <td><?=$model?></td>
              <td>
                <div style="width: 100px; height: 75px; border-radius: 10px; background-color: <?=$color?>; cursor: pointer;" title="<?=$color?>"></div>
              </td>
              <td>
                <?php
                  foreach($brands as $brand)
                  if($brand['id']==$brand_id){
                    echo $brand['title'];
                    break;
                  }
                ?>
              </td>
              <td><?=$daily_rate?></td>
              <td>
                <!-- Description Modal Trigger -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_desc_car_<?=$id?>" title="Read">
                  <i class="fa fa-eye"></i>
                </button>
                <!-- Description Modal -->
                <div class="modal fade" id="read_desc_car_<?=$id?>" tabindex="-1">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Description</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <p class="lead">
                          <?=$description?>
                        </p>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
              </td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_car_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>

                <!-- Update Modal Trigger -->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_car_<?=$id?>">
                  <i class="fa fa-edit"></i>
                </button>
                <!-- Update Modal -->
                <form class="modal fade" id="edit_car_<?=$id?>" tabindex="-1" aria-hidden="true" action="" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="update_car_id" value="<?=$id?>">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Update User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_title">Title</label>
                              <input type="text" class="form-control" name="title" id="update_<?=$id?>_title" placeholder="Title" value="<?=$title?>" required>
                            </div>
                          </div>
                          <div class="col-md-3 col-sm-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_model">Model</label>
                              <input type="number" min="1000" max="9999" class="form-control" name="model" id="update_<?=$id?>_model" placeholder="Model Year" value="<?=$model?>" required>
                            </div>
                          </div>
                          <div class="col-md-3 col-sm-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_color">Color</label>
                              <input type="color" class="form-control" name="color" id="update_<?=$id?>_color" value="<?=$color?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_brand_id">Brand</label>
                              <select name="brand_id" id="update_<?=$id?>_brand_id" class="form-control" required>
                                <option value="" class="d-none">Select Brand</option>
                                <?php
                                  foreach($brands as $brand){
                                    ?><option value="<?=$brand['id']?>"<?=$brand['id']==$brand_id?" selected":""?>><?=$brand['title']?></option><?php
                                  }
                                ?>
                              </select>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_daily_rate">Daily Rate</label>
                              <input type="number" min="1" class="form-control" name="daily_rate" id="update_<?=$id?>_daily_rate" placeholder="Daily Rate" value="<?=$daily_rate?>" required>
                            </div>
                          </div>
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="update_<?=$id?>_description">Description</label>
                              <textarea class="form-control" name="description" id="update_<?=$id?>_description" rows="3" placeholder="Enter Description" required><?=$description?></textarea>
                            </div>
                          </div>
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="update_<?=$id?>_img_src">Car Image (Upload To Change)</label>
                              <input type="file" type="image/*" class="form-control" name="img_src" id="update_<?=$id?>_img_src">
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                    </div>
                  </div>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>Image</th>
      <th>Title</th>
      <th>Model</th>
      <th>Color</th>
      <th>Brand</th>
      <th title="Daily">Rate</th>
      <th>Description</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<!-- Add New Car -->
<div class="jumbotron">
  <h1 class="display-4">Add new Car</h1>
  <p class="lead">
    Add New Car
  </p>
  <hr>
  <form action="" method="post" enctype="multipart/form-data">
    <input type="hidden" name="add_car" value="true">
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="title">Title</label>
          <input type="text" class="form-control" name="title" id="title" placeholder="Title" required>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="model">Model</label>
          <input type="number" min="1000" max="9999" class="form-control" name="model" id="model" placeholder="Model Year" required>
          <script>
            // Set Year equals Current year of User
            document.getElementById('model').value = (new Date).getFullYear();
          </script>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="color">Color</label>
          <input type="color" class="form-control" name="color" id="color" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="brand_id">Brand</label>
          <select name="brand_id" id="brand_id" class="form-control" required>
            <option value="" class="d-none" selected>Select Brand</option>
            <?php
              foreach($brands as $brand){
                ?><option value="<?=$brand['id']?>"><?=$brand['title']?></option><?php
              }
            ?>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="daily_rate">Daily Rate</label>
          <input type="number" min="1" class="form-control" name="daily_rate" id="daily_rate" placeholder="Daily Rate" required>
        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <label for="description">Description</label>
          <textarea class="form-control" name="description" id="description" rows="3" placeholder="Enter Description" required></textarea>
        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <label for="img_src">Car Image</label>
          <input type="file" type="image/*" class="form-control" name="img_src" id="img_src" required>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-car"></i>
      Add
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>


<!-- Brands -->
<div class="jumbotron">
  <h1 class="display-4">Brands</h1>
  <p class="lead">
    Manage your brands in followings:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>Brand Title</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($brands as $brand){
          extract($brand);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td><?=$title?></td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_brand_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
                
                <!-- Update Modal Trigger -->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_brand_<?=$id?>">
                  <i class="fa fa-edit"></i>
                </button>
                <!-- Update Modal -->
                <form class="modal fade" id="edit_brand_<?=$id?>" tabindex="-1" aria-hidden="true" action="" method="post">
                  <input type="hidden" name="update_brand_id" value="<?=$id?>">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Update Brand</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="update_<?=$id?>_brand">Brand Name</label>
                              <input type="text" class="form-control" name="brand" id="update_<?=$id?>_brand" placeholder="Brand Title" value="<?=$title?>" required>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                    </div>
                  </div>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>Brand</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<!-- Add Brand -->
<div class="jumbotron">
  <h1 class="display-4">Add new Brand</h1>
  <p class="lead">
    Add New Brand
  </p>
  <hr>
  <form action="" method="post">
    <input type="hidden" name="add_brand" value="true">
    <div class="row">
      <div class="col-12">
        <div class="form-group">
          <label for="brand">Brand Name</label>
          <input type="text" class="form-control" name="brand" id="brand" placeholder="Brand Name" required>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-plus"></i>
      Add
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>

<?php
  include "../views/layouts/dashboard/dashboard_end.php";
?>