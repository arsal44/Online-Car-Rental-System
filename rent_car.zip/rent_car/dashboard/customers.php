<?php
  // Required Files
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  $VIEW_BASE="views"; // Conf Var

  // Redirect No-Login
  if(!in_array($user['role'], ['a']))
  header('location: ../login.php');

  // Add Customer
  if(isset($_POST['add_customer'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM customers WHERE email = '$email';")){
      if(mysqli_num_rows($qry) == 0){
        if(mysqli_query($con, "INSERT INTO customers(email, passcode, phone, fname, lname, cnic, address) VALUES ('$email', '$password', '$phone', '$fname', '$lname', '$cnic', '$address');"))
        $msg = [
          "type" => "success",
          "msg" => "Customer Registered Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while inserting Customer!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Email Already Registered!",
      ];
    }
  }

  // Update Customer
  if(isset($_POST['update_customer_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM customers WHERE id=$update_customer_id;")){
      if(mysqli_num_rows($qry) == 1){
        if($qry=mysqli_query($con, "SELECT * FROM customers WHERE email='$email' AND id!=$update_customer_id;")){
          if(mysqli_num_rows($qry) == 0){
            if(mysqli_query($con, "UPDATE customers SET email='$email', passcode='$password', phone='$phone', address='$address', fname='$fname', lname='$lname', cnic='$cnic' WHERE id=$update_customer_id;"))
            $msg = [
              "type" => "success",
              "msg" => "Customer Updated Successfully!",
            ];
            else $msg = [
              "type" => "danger",
              "msg" => "Error while Updating Customer!",
            ];
          } else $msg = [
            "type" => "danger",
            "msg" => "Email Already Registered!",
          ];
        } else $msg = [
          "type" => "danger",
          "msg" => "Unable to Confirm Email!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Customer Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Customer!",
    ];
  }

  // Delete Customer
  if(isset($_POST['delete_customer_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM customers WHERE id=$delete_customer_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM customers WHERE Id=$delete_customer_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Customer Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting Customer!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Customer Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Customer!",
    ];
  }

  // Fetch Customers
  $customers = [];
  if($qry=mysqli_query($con, "SELECT * FROM customers;"))
  while($_customer=mysqli_fetch_assoc($qry))
  $customers[]=$_customer;
  else die("Unable to fetch customers from database");


  // Layout Start
  include "../views/layouts/dashboard/dashboard_start.php";
?>


<div class="jumbotron">
  <?php
    include "../includes/alert.php";
  ?>
  <h1 class="display-4">Customers</h1>
  <p class="lead">
    Manage your database customers in followings:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email Address</th>
      <th>CNIC / B-Form</th>
      <th>Phone</th>
      <th>Address</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($customers as $customer){
          extract($customer);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td><?=$fname?></td>
              <td><?=$lname?></td>
              <td><?=$email?></td>
              <td><?=$cnic?></td>
              <td><?=$phone?></td>
              <td>
                <!-- Address Modal Trigger -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_address_<?=$id?>" title="Read">
                  <i class="fa fa-eye"></i>
                </button>
                <!-- Address Modal -->
                <div class="modal fade" id="read_address_<?=$id?>" tabindex="-1">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Address</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <p class="lead">
                          <?=$address?>
                        </p>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
              </td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_customer_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
                
                <!-- Update Modal Trigger -->
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit_customer_<?=$id?>">
                  <i class="fa fa-edit"></i>
                </button>
                <!-- Update Modal -->
                <form class="modal fade" id="edit_customer_<?=$id?>" tabindex="-1" aria-hidden="true" action="" method="post">
                  <input type="hidden" name="update_customer_id" value="<?=$id?>">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Update User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_fname">First Name</label>
                              <input type="text" class="form-control" name="fname" id="update_<?=$id?>_fname" placeholder="First Name" value="<?=$fname?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_lname">Last Name</label>
                              <input type="text" class="form-control" name="lname" id="update_<?=$id?>_lname" placeholder="Last Name" value="<?=$lname?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_email">Email Address</label>
                              <input type="text" class="form-control" name="email" id="update_<?=$id?>_email" placeholder="Email Address" value="<?=$email?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_cnic">CNIC / B-Form</label>
                              <input type="text" class="form-control" name="cnic" id="update_<?=$id?>_cnic" placeholder="CNIC / B-Form" value="<?=$cnic?>" required>
                            </div>
                          </div>
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="update_<?=$id?>_address">Address</label>
                              <textarea class="form-control" name="address" id="update_<?=$id?>_address" rows="3" placeholder="Enter Address" required><?=$address?></textarea>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_phone">Phone</label>
                              <input type="text" class="form-control" name="phone" id="update_<?=$id?>_phone" placeholder="Phone" value="<?=$phone?>" required>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="update_<?=$id?>_password">Password</label>
                              <input type="password" class="form-control" name="password" id="update_<?=$id?>_password" placeholder="password" value="<?=$passcode?>" required>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                    </div>
                  </div>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email Address</th>
      <th>CNIC / B-Form</th>
      <th>Phone</th>
      <th>Address</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<div class="jumbotron">
  <h1 class="display-4">Create new Customer</h1>
  <p class="lead">
    Create New Customer Account
  </p>
  <hr>
  <form action="" method="post">
    <input type="hidden" name="add_customer" value="true">
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label for="fname">First Name</label>
          <input type="text" class="form-control" name="fname" id="fname" placeholder="First Name" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="lname">Last Name</label>
          <input type="text" class="form-control" name="lname" id="lname" placeholder="Last Name" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="email">Email Address</label>
          <input type="text" class="form-control" name="email" id="email" placeholder="Email Address" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="cnic">CNIC / B-Form</label>
          <input type="text" class="form-control" name="cnic" id="cnic" placeholder="CNIC / B-Form" required>
        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <label for="address">Address</label>
          <textarea class="form-control" name="address" id="address" rows="3" placeholder="Enter Address" required></textarea>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="phone">Phone</label>
          <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone" required>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group">
          <label for="password">First Password</label>
          <input type="password" class="form-control" name="password" id="password" placeholder="password" value="12345678" required>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-user-plus"></i>
      Register
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>


<?php
  // Layout End
  include "../views/layouts/dashboard/dashboard_end.php";
?>