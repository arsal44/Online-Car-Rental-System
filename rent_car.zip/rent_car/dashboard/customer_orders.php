<?php
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  $VIEW_BASE="views";

  if(!in_array($user['role'], ['c']))
  header('location: ../login.php');

  // Fetch Cars
  $cars = [];
  if($qry=mysqli_query($con, "SELECT *, (SELECT title FROM brands WHERE brands.id=cars.brand_id) AS brand FROM cars WHERE cars.id NOT IN (SELECT car_id FROM car_reservation WHERE order_status IN (1, 3));"))
  while($car=mysqli_fetch_assoc($qry))
  $cars[]=$car;
  else die("Unable to fetch cars from database");

  // Place Order
  if(isset($_POST['new_order'])){
    if( // Validate Data
      isset($_POST['car_id']) && !empty($_POST['car_id'])
      && isset($_POST['start_date']) && !empty($_POST['start_date'])
      && isset($_POST['port_time']) && !empty($_POST['port_time'])
      && isset($_POST['no_of_days']) && !empty($_POST['no_of_days'])
      && isset($_POST['lat']) && !empty($_POST['lat'])
      && isset($_POST['lng']) && !empty($_POST['lng'])
      && isset($_POST['port_address']) && !empty($_POST['no_of_days'])
    ){
      extract($_POST);
      // Default for message if absent
      if(!isset($message)) $message = '';

      $found=false;
      foreach($cars as $car){
        if($car_id==$car['id']){
          $found=true;
          break;
        }
      }

      // If Car Found
      if($found){
        // Insert into database
        if(mysqli_query($con, $qry = "INSERT INTO car_reservation(car_id, customer_id, driver, daily_rate, start_date, no_of_days, port_time, port_address, port_lat, port_lng, message, order_status) VALUES ('$car_id', '".$user['id']."', '".(isset($_POST['driver'])?'1':'0')."', '".$car['daily_rate']."', '$start_date', '$no_of_days', '$port_time', '$port_address', '$lat', '$lng', '$message', 0);"))
          $msg = [
            "type" => "success",
            "msg" => "Order Placed Successfully! Click pay button in actions to proceed.",
          ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Placing Order!" // . mysqli_error($con) . $qry
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Car does not exists!"
      ];
    } else 
    $msg = [
      "type" => "danger",
      "msg" => "Invalid Data to place Order!",
    ];
  }

  // Cancel Order
  if(isset($_POST['cancel_order_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM car_reservation WHERE id=$cancel_order_id AND customer_id='".$user['id']."' AND order_status=0;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM car_reservation WHERE id=$cancel_order_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Order Canceled Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Canceling Order!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "You do not have such a cancellable order!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Order!",
    ];
  }

  // Fetch Orders
  $orders = [];
  if($qry=mysqli_query($con, "SELECT * FROM car_reservation WHERE customer_id='".$user['id']."' ORDER BY date DESC, time DESC;"))
  while($order=mysqli_fetch_assoc($qry))
  $orders[]=$order;
  else die("Unable to fetch orders from database");

  include "../views/layouts/dashboard/dashboard_start.php";
?>
<div class="p-3">
  <?php
    include "../includes/alert.php";
  ?>
</div>

<!-- Required Assets -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key="></script>
<script src="../assets/map/location-picker.min.js"></script>
<style type="text/css">
  #map {
    width: 100%!important;
    height: 400px!important;
    transition: height .4s ease!important;
  }
  #map.sm {
    height: 200px!important;
  }
</style>

<!-- Orders -->
<div class="jumbotron">
  <h1 class="display-4">Orders</h1>
  <p class="lead">
    Manage your orders in followings. <span class="text-success">Kindly Give us a <a href="../feedback.php">Feedback</a> about your expereience.</span>:
  </p>
  <hr class="my-5">

  <div style="overflow-x: auto;">
    <table id="data_table" class="data_table table table-striped table-bordered" style="width:120%">
      <thead>
        <th>#</th>
        <th>Car</th>
        <th>Driver</th>
        <th>Days</th>
        <th>Amount</th>
        <th>Address</th>
        <th>Message</th>
        <th>Status</th>
        <th>Actions</th>
      </thead>
      <tbody>
        <?php
          $counter=0;
          foreach($orders as $order){
            extract($order);
            $counter++;
            ?>
              <tr>
                <td><?=$counter?></td>
                <td>
                  <?php
                    foreach($cars as $car)
                    if($car['id']==$car_id){
                      echo $car['brand'] . " " . $car['title'] . " " . $car['model']; //. " (Rs. " . $car['daily_rate'] . " /  Day)";
                      break;
                    }
                  ?>
                </td>
                <td><?=$driver?"Yes":"No"?></td>
                <td><?=$no_of_days?></td>
                <td>
                  <?="Rs. $daily_rate x $no_of_days<br>= Rs. " . ($daily_rate * $no_of_days)?>
                </td>
                <td>
                  <!-- Address Modal Trigger -->
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_addr_<?=$id?>" title="Read">
                    <i class="fa fa-eye"></i>
                  </button>
                  <!-- Address Modal -->
                  <div class="modal fade" id="read_addr_<?=$id?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Address</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <p class="lead">
                            <?=$port_address?>
                          </p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- Map Location Form -->
                  <form action="../map.php" method="GET" class="text-center d-inline-block">
                    <input type="hidden" name="lat" value="<?=$port_lat?>">
                    <input type="hidden" name="lng" value="<?=$port_lng?>">
                    <button type="submit" class="btn btn-default btn-success" title="Map Location">
                      <i class="mdi mdi-map-marker-radius"></i>
                    </button>
                  </form>
                </td>
                <td>
                  <!-- Message Modal Trigger -->
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_msg_<?=$id?>" title="Read">
                    <i class="fa fa-eye"></i>
                  </button>
                  <!-- Message Modal -->
                  <div class="modal fade" id="read_msg_<?=$id?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Message</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <p class="lead">
                            <?=$message?>
                          </p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
                <td>
                  <?php
                    switch($order_status){
                      case 0:
                        echo 'Pending Payment'; 
                        break;
                      case 1:
                        echo 'Payment Completed'; 
                        break;
                      case 2:
                        echo 'Payment Failed'; 
                        break;
                      case 3:
                        echo 'On Rent'; 
                        break;
                      case 4:
                        echo 'Completed'; 
                        break;
                      case 5:
                        echo 'Refounded'; 
                        break;
                      case 6:
                        echo 'Rejected'; 
                        break;
                      default:
                        echo 'Unknown'; 
                    }
                  ?>
                </td>
                <td>
                  <form action="" method="post" class="d-inline-block">
                    <input type="hidden" name="cancel_order_id" value="<?=$id?>">
                    <button type="submit" class="btn btn-danger" <?=($order_status!=0)?"disabled title='Contact to cancel manually.'":'title="Cancel"'?>>
                      &times;
                    </button>
                  </form>
                  <form action="customer_payments.php#new_payment" method="post" class="d-inline-block">
                    <input type="hidden" name="amount" value="<?=$daily_rate*$no_of_days?>">
                    <button type="submit" class="btn btn-success" title="Pay">
                      <i class="mdi mdi-format-float-center"></i>
                    </button>
                  </form>
                  <?=($order_status!=0)?"<br><br><span class='text-muted'>Contact to cancel manually.</span>":''?>
                </td>
              </tr>
            <?php
          }
        ?>
      </tbody>
      <tfoot>
        <th>#</th>
        <th>Car</th>
        <th>Driver</th>
        <th>Days</th>
        <th>Amount</th>
        <th>Address</th>
        <th>Message</th>
        <th>Status</th>
        <th>Actions</th>
      </tfoot>
    </table>
  </div>
</div>

<!-- Place Order Form -->
<div class="jumbotron" id="new_order">
  <h1 class="display-4">Place New Order</h1>
  <p class="lead">
    Place your order as follow
  </p>
  <hr>
  <form action="customer_orders.php" method="POST">
    <input type="hidden" name="new_order" value="true">
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <label for="car">Car</label>
          <select name="car_id" id="car" class="form-control" required>
            <option value="" selected class="d-none">Select Car</option>
            <?php
              foreach($cars as $car){
                extract($car);
                ?>
                  <option value="<?=$id?>"<?=(isset($_POST['car_id']) && $_POST['car_id']==$id)?" selected":""?>><?="$brand $title $model (Rs. $daily_rate / Day)"?></option>
                <?php
              }
            ?>
          </select>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="start_date">Date</label>
          <input type="date" class="form-control" name="start_date" id="start_date" required>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="port_time">Time</label>
          <input type="time" class="form-control" name="port_time" id="port_time" required>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="no_of_days">Number of Days</label>
          <input type="number" min="1" class="form-control" name="no_of_days" id="no_of_days" placeholder="Days" value="1" required>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="form-group">
          <label for="location">Location</label>
          <input type="button" value="Pick Location" class="form-control btn btn-primary"  data-bs-toggle="modal" data-bs-target="#pick_order_location" title="Picl Location">
          <!-- <button type="button" class="btn btn-success" data-toggle="modal" data-target="#flt_pick_loc"><i class="fa fa-globe"></i> Pick on Map</button> -->

          <div class="modal fade" id="pick_order_location" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Pick Location</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  <input type="hidden" name="lat" id="lat" value="">
                  <input type="hidden" name="lng" id="lng" value="">
                </div>
                <div class="modal-body">
                  <p class="lead text-muted">
                    Pick Your Location:
                  </p>
                  <div id="map" style="width: 100%; height: 300px;"></div>
                  <div class="text-center mt-3">
                    <button type="button" id="confirmPosition" class="btn btn-primary" data-dismiss="modal">Select Position</button>
                  </div>
                  <script>
                    var confirmBtn = document.getElementById('confirmPosition');
                    // var reselectBtn = document.getElementById('reselectPosition');
                    var lat = document.getElementById('lat');
                    var lng = document.getElementById('lng');
                    var lp = new locationPicker('map', {
                      setCurrentPosition: true,
                    }, {
                      zoom: 15
                    });
                    confirmBtn.onclick = function () {
                      var location = lp.getMarkerPosition();
                      lat.value = location.lat;
                      lng.value = location.lng;
                      alert("Location Picked!");
                      document.getElementById('map').classList.add('sm');
                    };
                    google.maps.event.addListener(lp.map, 'idle', function (event) {
                      var location = lp.getMarkerPosition();
                      // console.log(location.lat, location.lng);
                    });
                  </script>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <label for="port_address">Address</label>
          <textarea class="form-control" name="port_address" id="port_address" rows="3" placeholder="Type address"></textarea>
        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <label for="message">Message (Optional)</label>
          <textarea class="form-control" name="message" id="message" rows="3" placeholder="Enter a messages (optional)"></textarea>
        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <input type="checkbox" name="driver" id="driver" vlaue="yes">
          <label for="driver">I need a driver also.</label>
        </div>
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-success">
      <i class="fa fa-car"></i>
      Order
    </button>
    <button type="reset" class="btn btn-secondary">Clear</button>
  </form>
</div>

<?php
  include "../views/layouts/dashboard/dashboard_end.php";
?>