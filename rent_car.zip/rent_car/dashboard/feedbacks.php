<?php
  // Required Files
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  $VIEW_BASE="views"; // Conf Var

  // Redirect No-Login
  if(!in_array($user['role'], ['a']))
  header('location: ../login.php');


  // Delete Feedback
  if(isset($_POST['delete_feedback_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM feedbacks WHERE id=$delete_feedback_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM feedbacks WHERE Id=$delete_feedback_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Feedback Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting Feedback!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Feedback Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Feedback!",
    ];
  }

  // Fetch Feedbacks
  $feedbacks = [];
  if($qry=mysqli_query($con, "SELECT feedbacks.id, feedbacks.customer_id, feedbacks.title, feedbacks.feedback_type, feedbacks.message, feedbacks.date, feedbacks.time, customers.fname, customers.lname, customers.email, customers.cnic, customers.phone, customers.address FROM feedbacks INNER JOIN customers ON customers.id=feedbacks.customer_id ORDER BY date DESC, time DESC;"))
  while($feedback=mysqli_fetch_assoc($qry))
  $feedbacks[]=$feedback;
  else die("Unable to fetch feedbacks from database");

  // Layout Start
  include "../views/layouts/dashboard/dashboard_start.php";
?>


<div class="jumbotron">
  <h1 class="display-4">Feedbacks</h1>
  <p class="lead">
    Following feedbacks have been submitted over time:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>Customer</th>
      <th>Title</th>
      <th>Message</th>
      <th>Date - Time</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($feedbacks as $feedback){
          extract($feedback);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td>
                <span class="text-primary" style="cursor:pointer;" title="<?=$phone?> <?=$email?>"><?=$fname . " " . $lname?></span>
              </td>
              <td><?=$title?></td>
              <td>
                <!-- Message Modal Trigger -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_message_<?=$id?>" title="Read">
                  <i class="fa fa-eye"></i>
                </button>
                <!-- Message Modal -->
                <div class="modal fade" id="read_message_<?=$id?>" tabindex="-1">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Message</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <p class="lead">
                          <?=$message?>
                        </p>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
              </td>
              <td><?="$date $time"?></td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_feedback_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>Customer</th>
      <th>Title</th>
      <th>Message</th>
      <th>Date - Time</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<?php
  // Layout End
  include "../views/layouts/dashboard/dashboard_end.php";
?>