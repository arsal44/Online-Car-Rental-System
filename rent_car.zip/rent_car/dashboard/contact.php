<?php
  // Required Files
  if(!isset($con)) require "../includes/conn.php";
  if(!isset($user)) require "../includes/auth.php";
  $VIEW_BASE="views"; // Conf Var

  // Redirect No-Login
  if(!in_array($user['role'], ['a']))
  header('location: ../login.php');


  // Delete Feedback
  if(isset($_POST['delete_contact_id'])){
    extract($_POST);
    if($qry=mysqli_query($con, "SELECT * FROM contacts WHERE id=$delete_contact_id;")){
      if(mysqli_num_rows($qry) == 1){
        if(mysqli_query($con, "DELETE FROM contacts WHERE Id=$delete_contact_id;"))
        $msg = [
          "type" => "success",
          "msg" => "Contact Message Deleted Successfully!",
        ];
        else $msg = [
          "type" => "danger",
          "msg" => "Error while Deleting Contact Message!",
        ];
      } else $msg = [
        "type" => "danger",
        "msg" => "Contact Message Does not Exists!",
      ];
    } else $msg = [
      "type" => "danger",
      "msg" => "Unable to Confirm Contact Message!",
    ];
  }

  // Fetch Contact Messages
  $contacts = [];
  if($qry=mysqli_query($con, "SELECT * FROM contact_messages ORDER BY date DESC, time DESC;"))
  while($contact=mysqli_fetch_assoc($qry))
  $contacts[]=$contact;
  else die("Unable to fetch contact messages from database");

  // Layout Start
  include "../views/layouts/dashboard/dashboard_start.php";
?>


<div class="jumbotron">
  <h1 class="display-4">Contact Messages</h1>
  <p class="lead">
    Following contact messages have been submitted over time:
  </p>
  <hr class="my-5">
  <table id="data_table" class="data_table table table-striped table-bordered" style="width:100%">
    <thead>
      <th>#</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email</th>
      <th>Subject</th>
      <th>Message</th>
      <th>Date - Time</th>
      <th>Actions</th>
    </thead>
    <tbody>
      <?php
        $counter=0;
        foreach($contacts as $contact){
          extract($contact);
          $counter++;
          ?>
            <tr>
              <td><?=$counter?></td>
              <td><?=$fname?></td>
              <td><?=$lname?></td>
              <td><?=$email?></td>
              <td><?=$subject?></td>
              <td>
                <!-- Message Modal Trigger -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#read_message_<?=$id?>" title="Read">
                  <i class="fa fa-eye"></i>
                </button>
                <!-- Message Modal -->
                <div class="modal fade" id="read_message_<?=$id?>" tabindex="-1">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Message</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <p class="lead">
                          <?=$message?>
                        </p>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
              </td>
              <td><?="$date $time"?></td>
              <td>
                <form action="" method="post" class="d-inline-block">
                  <input type="hidden" name="delete_contact_id" value="<?=$id?>">
                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php
        }
      ?>
    </tbody>
    <tfoot>
      <th>#</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Email</th>
      <th>Subject</th>
      <th>Message</th>
      <th>Date - Time</th>
      <th>Actions</th>
    </tfoot>
  </table>
</div>

<?php
  // Layout End
  include "../views/layouts/dashboard/dashboard_end.php";
?>